function startchat() {
    window.location.href = 'startchat.html';
}
function home() {
    window.location.href = 'home.html';
}
function search() {
    window.location.href = 'search.html';
}
function explore() {
    window.location.href = 'explore.html';
}
function profile() {
    window.location.href = 'profile.html';
}
function notification() {
    window.location.href = 'notification.html';
}

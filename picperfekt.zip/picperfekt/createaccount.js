function createaccount() {
    window.location.href = 'home.html';
}